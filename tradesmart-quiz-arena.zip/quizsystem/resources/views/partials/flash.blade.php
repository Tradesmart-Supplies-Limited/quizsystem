@if (session('success'))
    <div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle"></i> {{ session('success') }}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
@endif
@if (session('error'))
    <div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-triangle"></i> {{ session('error') }}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
@endif
@if (session('import_errors'))
    <div class="alert alert-warning"><strong>Some rows were skipped:</strong><ul class="mb-0">@foreach (session('import_errors') as $e)<li>{{ $e }}</li>@endforeach</ul></div>
@endif
@if ($errors->any())
    <div class="alert alert-danger"><strong>Please fix the following:</strong><ul class="mb-0">@foreach ($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul></div>
@endif
